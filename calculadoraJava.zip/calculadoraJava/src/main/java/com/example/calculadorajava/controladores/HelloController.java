package com.example.calculadorajava.controladores;

import com.example.calculadorajava.facade.FacadeOperacionBinaria;
import com.example.calculadorajava.operaciones.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Objects;

public class HelloController {

    //Atributos necesarios:
    private FacadeOperacionBinaria facade;
    private String currentNumber = "";
    private String firstNumber = "";
    private String calculationType;

    @FXML
    private TextField TextField;

    @FXML
    private Text savedNumbers;


    public void updateTextField() {
        TextField.setText(currentNumber);
    }


    public void addNumber(String number){
        currentNumber += number;
        updateTextField();
    }

    @FXML
    void button0Clicked(MouseEvent event) {
        addNumber("0");
    }

    @FXML
    void button1Clicked(MouseEvent event) {
        addNumber("1");
    }

    @FXML
    void button2Clicked(MouseEvent event) {
        addNumber("2");
    }

    @FXML
    void button3Clicked(MouseEvent event) {
        addNumber("3");
    }

    @FXML
    void button4Clicked(MouseEvent event) {
        addNumber("4");
    }

    @FXML
    void button5Clicked(MouseEvent event) {
        addNumber("5");
    }

    @FXML
    void button6Clicked(MouseEvent event) {
        addNumber("6");
    }

    @FXML
    void button7Clicked(MouseEvent event) {
        addNumber("7");
    }

    @FXML
    void button8Clicked(MouseEvent event) {
        addNumber("8");
    }

    @FXML
    void button9Clicked(MouseEvent event) {
        addNumber("9");
    }

    @FXML
    void calculate(ActionEvent event) {
        if (!Objects.equals(currentNumber, "")) {
            BigInteger firstNumberInt = BigInteger.valueOf(Long.parseLong(firstNumber));
            BigInteger secondNumberInt = BigInteger.valueOf(Long.parseLong(currentNumber));
            BigDecimal calculatedNumber =  facade.ejecutarOperacionBinaria(calculationType,firstNumberInt,secondNumberInt);
            savedNumbers.setText(firstNumber + " " + calculationType + " " + currentNumber + " = " + calculatedNumber);
            TextField.setText(String.valueOf(calculatedNumber));
        } else {
            savedNumbers.setText("Error");
            TextField.setText("0");
        }
    }




    @FXML
        void clearTextField(ActionEvent event) {
        currentNumber = "";
        TextField.setText("");
        savedNumbers.setText("");
    }

    @FXML
    void addAction(ActionEvent event) {
        calculationSetup("Suma");
    }

    @FXML
    void dividirAction(ActionEvent event) {
        calculationSetup("Division");
    }

    @FXML
    void multiplicarAction(ActionEvent event) {
        calculationSetup("Multiplicacion");
    }

    @FXML
    void restarAction(ActionEvent event) {
        calculationSetup("Resta");
    }

    public void calculationSetup(String calculationType){
        if (!currentNumber.equals("")) {
            this.calculationType = calculationType;
            firstNumber = currentNumber;
            currentNumber = "";
            savedNumbers.setText(firstNumber + " " + calculationType);
        }
        else{
            savedNumbers.setText("Error");
            TextField.setText("0");
        }
    }
}