module com.example.calculadorajava {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;

    requires org.controlsfx.controls;
    requires validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires eu.hansolo.tilesfx;

    opens com.example.calculadorajava to javafx.fxml;
    exports com.example.calculadorajava;
    exports com.example.calculadorajava.controladores;
    opens com.example.calculadorajava.controladores to javafx.fxml;
}