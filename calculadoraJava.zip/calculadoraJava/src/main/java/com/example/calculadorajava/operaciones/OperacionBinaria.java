package com.example.calculadorajava.operaciones;

import java.math.BigDecimal;
import java.math.BigInteger;

public interface OperacionBinaria {

    BigDecimal realizarOperacion(BigInteger num1, BigInteger num2);

}
