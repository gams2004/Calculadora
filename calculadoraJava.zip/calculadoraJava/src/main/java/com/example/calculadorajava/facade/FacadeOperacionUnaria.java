package com.example.calculadorajava.facade;

import java.math.BigDecimal;
import java.math.BigInteger;

public interface FacadeOperacionUnaria {

    BigDecimal ejecucionOperacionUnaria(String operacion, BigInteger numero1);
}
